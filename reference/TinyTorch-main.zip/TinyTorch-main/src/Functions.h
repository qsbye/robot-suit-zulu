/*
 * TinyTorch
 * @author 	: keith@robot9.me
 *
 */

#pragma once

#include "Function/FuncActivation.h"
#include "Function/FuncElemWise.h"
#include "Function/FuncFused.h"
#include "Function/FuncLinalg.h"
#include "Function/FuncLoss.h"
#include "Function/FuncNNLayer.h"
#include "Function/FuncReduce.h"
#include "Function/FuncSampling.h"
#include "Function/FuncTransform.h"
