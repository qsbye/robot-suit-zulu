/*
 * Copyright (C) 2023-2024 OpenMV, LLC.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Any redistribution, use, or modification in source or binary form
 *    is done solely for personal benefit and not for any commercial
 *    purpose or for monetary gain. For commercial licensing options,
 *    please contact openmv@openmv.io
 *
 * THIS SOFTWARE IS PROVIDED BY THE LICENSOR AND COPYRIGHT OWNER "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE LICENSOR OR COPYRIGHT
 * OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * CMOS sensor interface abstraction layer.
 */
#ifndef __OMV_CSI_H__
#define __OMV_CSI_H__
#include <stdint.h>
#include "omv_i2c.h"
#include "imlib.h"
#include "framebuffer.h"

#define OV2640_SLV_ADDR         (0x60)
#define OV5640_SLV_ADDR         (0x78)
#define OV7725_SLV_ADDR         (0x42)
#define MT9V0XX_SLV_ADDR        (0xB8)
#define MT9M114_SLV_ADDR        (0x90)
#define BOSON_SLV_ADDR          (0xAE)
#define LEPTON_SLV_ADDR         (0x54)
#define HM0XX0_SLV_ADDR         (0x48)
#define GC2145_SLV_ADDR         (0x78)
#define GENX320_SLV_ADDR        (0x78)
#define FROGEYE2020_SLV_ADDR    (0x6E)
#define PAG7920_SLV_ADDR        (0x80)
#define PAG7936_SLV_ADDR        (0x80)
#define PAG7936_SLV_ADDR_MIPI   (0x2A)
#define PS5520_SLV_ADDR         (0x90)

// Chip ID Registers
#define OV5640_CHIP_ID          (0x300A)
#define OV_CHIP_ID              (0x0A)
#define ON_CHIP_ID              (0x00)
#define HIMAX_CHIP_ID           (0x0001)
#define GC_CHIP_ID              (0xF0)
#define GENX320_CHIP_ID         (0x0014)
#define PIXART_CHIP_ID          (0x0000)

// Chip ID Values
#define OV2640_ID               (0x26)
#define OV5640_ID               (0x56)
#define OV7670_ID               (0x76)
#define OV7690_ID               (0x76)
#define OV7725_ID               (0x77)
#define OV9650_ID               (0x96)
#define MT9V0X2_ID_V_1          (0x1311)
#define MT9V0X2_ID_V_2          (0x1312)
#define MT9V0X2_ID              (0x1313)
#define MT9V0X2_C_ID            (0x1413)
#define MT9V0X4_ID              (0x1324)
#define MT9V0X4_C_ID            (0x1424)
#define MT9M114_ID              (0x2481)
#define BOSON_ID                (0xAE)
#define BOSON_320_ID            (0xAE32)
#define BOSON_640_ID            (0xAE64)
#define LEPTON_ID               (0x54)
#define LEPTON_1_5              (0x5415)
#define LEPTON_1_6              (0x5416)
#define LEPTON_2_0              (0x5420)
#define LEPTON_2_5              (0x5425)
#define LEPTON_3_0              (0x5430)
#define LEPTON_3_1R             (0x5431)
#define LEPTON_UW               (0x5432)
#define LEPTON_3_5              (0x5435)
#define HM01B0_ID               (0xB0)
#define HM0360_ID               (0x60)
#define GC2145_ID               (0x21)
#define GENX320_ID_ES           (0x30501C01)
#define GENX320_ID_MP           (0xB0602003)
#define PAG7920_ID              (0x7920)
#define PAG7936_ID              (0x7936)
#define PS5520_ID               (0x5520)
#define PAJ6100_ID              (0x6100)
#define FROGEYE2020_ID          (0x2020)
#define SOFTCSI_ID              (0x50F7)

#define OMV_CSI_TIMEOUT_MS      (3000)

#define OMV_CSI_CLK_SOURCE_MCO  (0U)
#define OMV_CSI_CLK_SOURCE_TIM  (1U)
#define OMV_CSI_CLK_SOURCE_OSC  (2U)

#ifndef OMV_CSI_MAX_DEVICES
#define OMV_CSI_MAX_DEVICES     (1)
#endif

typedef enum {
    OMV_CSI_ACTIVE_LOW  = 0,
    OMV_CSI_ACTIVE_HIGH = 1
} omv_csi_polarity_t;

typedef enum {
    OMV_CSI_CONFIG_INIT      = (1 << 0),
    OMV_CSI_CONFIG_DEINIT    = (1 << 1),
    OMV_CSI_CONFIG_FRAMESIZE = (1 << 2),
    OMV_CSI_CONFIG_PIXFORMAT = (1 << 3),
    OMV_CSI_CONFIG_WINDOWING = (1 << 4),
} omv_csi_config_t;

typedef enum {
    OMV_CSI_SDE_NORMAL,
    OMV_CSI_SDE_NEGATIVE,
} omv_csi_sde_t;

typedef enum {
    OMV_CSI_ATTR_CONTRAST=0,
    OMV_CSI_ATTR_BRIGHTNESS,
    OMV_CSI_ATTR_SATURATION,
    OMV_CSI_ATTR_GAINCEILING,
} omv_csi_attr_t;

typedef enum {
    OMV_CSI_GAINCEILING_2X,
    OMV_CSI_GAINCEILING_4X,
    OMV_CSI_GAINCEILING_8X,
    OMV_CSI_GAINCEILING_16X,
    OMV_CSI_GAINCEILING_32X,
    OMV_CSI_GAINCEILING_64X,
    OMV_CSI_GAINCEILING_128X,
} omv_csi_gainceiling_t;

typedef enum {
    OMV_CSI_FRAMESIZE_INVALID = 0,
    OMV_CSI_FRAMESIZE_CUSTOM,
    // C/SIF Resolutions
    OMV_CSI_FRAMESIZE_QQCIF,    // 88x72
    OMV_CSI_FRAMESIZE_QCIF,     // 176x144
    OMV_CSI_FRAMESIZE_CIF,      // 352x288
    OMV_CSI_FRAMESIZE_QQSIF,    // 88x60
    OMV_CSI_FRAMESIZE_QSIF,     // 176x120
    OMV_CSI_FRAMESIZE_SIF,      // 352x240
    // VGA Resolutions
    OMV_CSI_FRAMESIZE_QQQQVGA,  // 40x30
    OMV_CSI_FRAMESIZE_QQQVGA,   // 80x60
    OMV_CSI_FRAMESIZE_QQVGA,    // 160x120
    OMV_CSI_FRAMESIZE_QVGA,     // 320x240
    OMV_CSI_FRAMESIZE_VGA,      // 640x480
    OMV_CSI_FRAMESIZE_HQQQQVGA, // 30x20
    OMV_CSI_FRAMESIZE_HQQQVGA,  // 60x40
    OMV_CSI_FRAMESIZE_HQQVGA,   // 120x80
    OMV_CSI_FRAMESIZE_HQVGA,    // 240x160
    OMV_CSI_FRAMESIZE_HVGA,     // 480x320
    // FFT Resolutions
    OMV_CSI_FRAMESIZE_64X32,    // 64x32
    OMV_CSI_FRAMESIZE_64X64,    // 64x64
    OMV_CSI_FRAMESIZE_128X64,   // 128x64
    OMV_CSI_FRAMESIZE_128X128,  // 128x128
    // Himax Resolutions
    OMV_CSI_FRAMESIZE_160X160,  // 160x160
    OMV_CSI_FRAMESIZE_320X320,  // 320x320
    // Other
    OMV_CSI_FRAMESIZE_LCD,      // 128x160
    OMV_CSI_FRAMESIZE_QQVGA2,   // 128x160
    OMV_CSI_FRAMESIZE_WVGA,     // 720x480
    OMV_CSI_FRAMESIZE_WVGA2,    // 752x480
    OMV_CSI_FRAMESIZE_SVGA,     // 800x600
    OMV_CSI_FRAMESIZE_XGA,      // 1024x768
    OMV_CSI_FRAMESIZE_WXGA,     // 1280x768
    OMV_CSI_FRAMESIZE_SXGA,     // 1280x1024
    OMV_CSI_FRAMESIZE_SXGAM,    // 1280x960
    OMV_CSI_FRAMESIZE_UXGA,     // 1600x1200
    OMV_CSI_FRAMESIZE_HD,       // 1280x720
    OMV_CSI_FRAMESIZE_FHD,      // 1920x1080
    OMV_CSI_FRAMESIZE_QHD,      // 2560x1440
    OMV_CSI_FRAMESIZE_QXGA,     // 2048x1536
    OMV_CSI_FRAMESIZE_WQXGA,    // 2560x1600
    OMV_CSI_FRAMESIZE_WQXGA2,   // 2592x1944
    OMV_CSI_FRAMESIZE_MAX,
} omv_csi_framesize_t;

// Flags for omv_csi_snapshot().
typedef enum {
    OMV_CSI_FLAG_NO_UPDATE      = (1 << 0),
    OMV_CSI_FLAG_NON_BLOCK      = (1 << 1),
    OMV_CSI_FLAG_NO_POST        = (1 << 2),
} omv_csi_flags_t;

// An ioctl request packs the sensor family it belongs to, so each family can
// be extended without renumbering the others.
#define OMV_CSI_IOCTL_INDEX_MASK    (0x00FF)
#define OMV_CSI_IOCTL_FAMILY_MASK   (0x0F00)
#define OMV_CSI_IOCTL_FAMILY_SHIFT  (8)
#define OMV_CSI_IOCTL_INDEX(r)      ((r) & OMV_CSI_IOCTL_INDEX_MASK)
#define OMV_CSI_IOCTL_FAMILY(r)     (((r) & OMV_CSI_IOCTL_FAMILY_MASK) >> OMV_CSI_IOCTL_FAMILY_SHIFT)

typedef enum {
    OMV_CSI_IOCTL_FAMILY_COMMON   = 0,
    OMV_CSI_IOCTL_FAMILY_LEPTON   = 1,
    OMV_CSI_IOCTL_FAMILY_HIMAX    = 2,
    OMV_CSI_IOCTL_FAMILY_GENX320  = 3,
    OMV_CSI_IOCTL_FAMILY_BOSON    = 4,
    // Not reachable from Python.
    OMV_CSI_IOCTL_FAMILY_INTERNAL = 15,
} omv_csi_ioctl_family_t;

// Requests carry this flag, so driver case labels match the flagged value.
typedef enum {
    OMV_CSI_IOCTL_FLAG_ABORT    = (1 << 15),
} omv_csi_ioctl_flags_t;

_Static_assert((OMV_CSI_IOCTL_FLAG_ABORT &
                (OMV_CSI_IOCTL_FAMILY_MASK | OMV_CSI_IOCTL_INDEX_MASK)) == 0,
               "ioctl abort flag overlaps the family or index field");

typedef enum {
    // Common requests, implemented by any sensor.
    OMV_CSI_IOCTL_SET_READOUT_WINDOW              = 0x000 | OMV_CSI_IOCTL_FLAG_ABORT,
    OMV_CSI_IOCTL_GET_READOUT_WINDOW              = 0x001,
    OMV_CSI_IOCTL_SET_TRIGGERED_MODE              = 0x002,
    OMV_CSI_IOCTL_GET_TRIGGERED_MODE              = 0x003,
    OMV_CSI_IOCTL_SET_FOV_WIDE                    = 0x004,
    OMV_CSI_IOCTL_GET_FOV_WIDE                    = 0x005,
    OMV_CSI_IOCTL_TRIGGER_AUTO_FOCUS              = 0x006,
    OMV_CSI_IOCTL_PAUSE_AUTO_FOCUS                = 0x007,
    OMV_CSI_IOCTL_RESET_AUTO_FOCUS                = 0x008,
    OMV_CSI_IOCTL_WAIT_ON_AUTO_FOCUS              = 0x009,
    OMV_CSI_IOCTL_SET_NIGHT_MODE                  = 0x00A,
    OMV_CSI_IOCTL_GET_NIGHT_MODE                  = 0x00B,
    OMV_CSI_IOCTL_GET_RGB_STATS                   = 0x00C,

    // FLIR Lepton.
    OMV_CSI_IOCTL_LEPTON_GET_WIDTH                = 0x100,
    OMV_CSI_IOCTL_LEPTON_GET_HEIGHT               = 0x101,
    OMV_CSI_IOCTL_LEPTON_GET_RADIOMETRY           = 0x102,
    OMV_CSI_IOCTL_LEPTON_GET_REFRESH              = 0x103,
    OMV_CSI_IOCTL_LEPTON_GET_RESOLUTION           = 0x104,
    OMV_CSI_IOCTL_LEPTON_RUN_COMMAND              = 0x105,
    OMV_CSI_IOCTL_LEPTON_SET_ATTRIBUTE            = 0x106,
    OMV_CSI_IOCTL_LEPTON_GET_ATTRIBUTE            = 0x107,
    OMV_CSI_IOCTL_LEPTON_GET_FPA_TEMP             = 0x108,
    OMV_CSI_IOCTL_LEPTON_GET_AUX_TEMP             = 0x109,
    OMV_CSI_IOCTL_LEPTON_SET_MODE                 = 0x10A | OMV_CSI_IOCTL_FLAG_ABORT,
    OMV_CSI_IOCTL_LEPTON_GET_MODE                 = 0x10B,
    OMV_CSI_IOCTL_LEPTON_SET_RANGE                = 0x10C | OMV_CSI_IOCTL_FLAG_ABORT,
    OMV_CSI_IOCTL_LEPTON_GET_RANGE                = 0x10D,

    // Himax.
    OMV_CSI_IOCTL_HIMAX_MD_ENABLE                 = 0x200,
    OMV_CSI_IOCTL_HIMAX_MD_CLEAR                  = 0x201,
    OMV_CSI_IOCTL_HIMAX_MD_WINDOW                 = 0x202 | OMV_CSI_IOCTL_FLAG_ABORT,
    OMV_CSI_IOCTL_HIMAX_MD_THRESHOLD              = 0x203,
    OMV_CSI_IOCTL_HIMAX_OSC_ENABLE                = 0x204 | OMV_CSI_IOCTL_FLAG_ABORT,

    // Prophesee GenX320.
    OMV_CSI_IOCTL_GENX320_SET_BIASES              = 0x300,
    OMV_CSI_IOCTL_GENX320_SET_BIAS                = 0x301,
    OMV_CSI_IOCTL_GENX320_SET_AFK                 = 0x302,
    OMV_CSI_IOCTL_GENX320_SET_MODE                = 0x303,
    OMV_CSI_IOCTL_GENX320_READ_EVENTS             = 0x304,
    OMV_CSI_IOCTL_GENX320_CALIBRATE               = 0x305,
    OMV_CSI_IOCTL_GENX320_SET_STC                 = 0x306,
    OMV_CSI_IOCTL_GENX320_READ_EVENTS_RAW         = 0x307,

    // FLIR Boson.
    OMV_CSI_IOCTL_BOSON_GET_SOFTWARE_REV          = 0x400,
    OMV_CSI_IOCTL_BOSON_GET_FPA_TEMP              = 0x401,
    OMV_CSI_IOCTL_BOSON_SET_GAIN_MODE             = 0x402,
    OMV_CSI_IOCTL_BOSON_GET_GAIN_MODE             = 0x403,
    OMV_CSI_IOCTL_BOSON_RUN_FFC                   = 0x404,
    OMV_CSI_IOCTL_BOSON_GET_FFC_STATUS            = 0x405,
    OMV_CSI_IOCTL_BOSON_SET_FFC_MODE              = 0x406,
    OMV_CSI_IOCTL_BOSON_GET_FFC_MODE              = 0x407,
    OMV_CSI_IOCTL_BOSON_SET_FFC_TEMP_THRESHOLD    = 0x408,
    OMV_CSI_IOCTL_BOSON_GET_FFC_TEMP_THRESHOLD    = 0x409,
    OMV_CSI_IOCTL_BOSON_SET_FFC_FRAME_THRESHOLD   = 0x40A,
    OMV_CSI_IOCTL_BOSON_GET_FFC_FRAME_THRESHOLD   = 0x40B,
    OMV_CSI_IOCTL_BOSON_SET_FFC_NUM_FRAMES        = 0x40C,
    OMV_CSI_IOCTL_BOSON_GET_FFC_NUM_FRAMES        = 0x40D,
    OMV_CSI_IOCTL_BOSON_GET_RADIOMETRY_CAPABLE    = 0x40E,
    OMV_CSI_IOCTL_BOSON_SET_TLINEAR_ENABLE        = 0x40F,
    OMV_CSI_IOCTL_BOSON_GET_TLINEAR_ENABLE        = 0x410,
    OMV_CSI_IOCTL_BOSON_SET_TEMP_STABLE_ENABLE    = 0x411,
    OMV_CSI_IOCTL_BOSON_GET_TEMP_STABLE_ENABLE    = 0x412,
    OMV_CSI_IOCTL_BOSON_SET_EMISSIVITY            = 0x413,
    OMV_CSI_IOCTL_BOSON_GET_EMISSIVITY            = 0x414,
    OMV_CSI_IOCTL_BOSON_SET_TEMP_BACKGROUND       = 0x415,
    OMV_CSI_IOCTL_BOSON_GET_TEMP_BACKGROUND       = 0x416,
    OMV_CSI_IOCTL_BOSON_SET_SPOT_METER_ENABLE     = 0x417,
    OMV_CSI_IOCTL_BOSON_GET_SPOT_METER_ENABLE     = 0x418,
    OMV_CSI_IOCTL_BOSON_SET_SPOT_METER_ROI        = 0x419,
    OMV_CSI_IOCTL_BOSON_GET_SPOT_METER_ROI        = 0x41A,
    OMV_CSI_IOCTL_BOSON_GET_SPOT_METER_ROI_MAX    = 0x41B,
    OMV_CSI_IOCTL_BOSON_SET_SPOT_METER_MODE       = 0x41C,
    OMV_CSI_IOCTL_BOSON_GET_SPOT_METER_MODE       = 0x41D,
    OMV_CSI_IOCTL_BOSON_GET_SPOT_METER_STATS      = 0x41E,
    OMV_CSI_IOCTL_BOSON_GET_SPOT_METER_TEMP_STATS = 0x41F,
    OMV_CSI_IOCTL_BOSON_GET_TEMP_FROM_COUNTS      = 0x420,
    OMV_CSI_IOCTL_BOSON_GET_RBFO                  = 0x421,

    // Internal requests, not exported to Python.
    OMV_CSI_IOCTL_UPDATE_AGC_AEC                  = 0xF00,
} omv_csi_ioctl_t;

typedef struct {
    int32_t x;
    int32_t y;
    int32_t w;
    int32_t h;
} omv_csi_window_t;

// Generic argument for the ioctls.
typedef union {
    int32_t ivalue;
    omv_csi_window_t window;
    struct {
        uint32_t r;
        uint32_t gb;
        uint32_t gr;
        uint32_t b;
    } rgb_stats;
} omv_csi_ioctl_arg_t;

typedef enum {
    OMV_CSI_ERROR_NO_ERROR              =  0,
    OMV_CSI_ERROR_CTL_FAILED            = -1,
    OMV_CSI_ERROR_CTL_UNSUPPORTED       = -2,
    OMV_CSI_ERROR_ISC_UNDETECTED        = -3,
    OMV_CSI_ERROR_ISC_UNSUPPORTED       = -4,
    OMV_CSI_ERROR_ISC_INIT_FAILED       = -5,
    OMV_CSI_ERROR_TIM_INIT_FAILED       = -6,
    OMV_CSI_ERROR_DMA_INIT_FAILED       = -7,
    OMV_CSI_ERROR_CSI_INIT_FAILED       = -8,
    OMV_CSI_ERROR_IO_ERROR              = -9,
    OMV_CSI_ERROR_CAPTURE_FAILED        = -10,
    OMV_CSI_ERROR_CAPTURE_TIMEOUT       = -11,
    OMV_CSI_ERROR_INVALID_FRAMESIZE     = -12,
    OMV_CSI_ERROR_INVALID_PIXFORMAT     = -13,
    OMV_CSI_ERROR_INVALID_WINDOW        = -14,
    OMV_CSI_ERROR_INVALID_FRAMERATE     = -15,
    OMV_CSI_ERROR_INVALID_ARGUMENT      = -16,
    OMV_CSI_ERROR_PIXFORMAT_UNSUPPORTED = -17,
    OMV_CSI_ERROR_FRAMEBUFFER_ERROR     = -18,
    OMV_CSI_ERROR_FRAMEBUFFER_OVERFLOW  = -19,
    OMV_CSI_ERROR_JPEG_OVERFLOW         = -20,
    OMV_CSI_ERROR_WOULD_BLOCK           = -21,
} omv_csi_error_t;


typedef struct _omv_csi omv_csi_t;

typedef struct _omv_csi_callback_t {
    void (*fun) (void *);
    void *arg;
} omv_csi_cb_t;

typedef int (*omv_csi_snapshot_t)
    (omv_csi_t *csi, image_t *image, uint32_t flags);

typedef int (*omv_csi_post_process_t)
    (omv_csi_t *csi, image_t *image, uint32_t flags);

typedef struct _omv_clk omv_clk_t;

typedef struct _omv_clk {
    uint32_t freq;
    #ifdef OMV_CSI_CLK_PORT_BITS
    OMV_CSI_CLK_PORT_BITS
    #endif
    uint32_t (*get_freq) (omv_clk_t *csi);
    int (*set_freq) (omv_clk_t *csi, uint32_t freq);
} omv_clk_t;

#if defined(OMV_CSI_STATS_ENABLE)
typedef struct omv_csi_stats {
    bool initialized;
    uint32_t last_ms;
    float r_avg;
    float g_avg;
    float b_avg;
} omv_csi_stats_t;
#endif // defined(OMV_CSI_STATS_ENABLE)

typedef struct _omv_csi {
    uint32_t chip_id;           // Sensor ID 32 bits.
    uint8_t slv_addr;           // Sensor I2C slave address.

    // Hardware flags (clock polarities, hw capabilities etc..)
    struct {
        uint32_t reset_pol  : 1;  // Reset polarity.
        uint32_t power_pol  : 1;  // Power-down polarity.
        uint32_t vsync_pol  : 1;  // Vertical sync polarity.
        uint32_t hsync_pol  : 1;  // Horizontal sync polarity.
        uint32_t pixck_pol  : 1;  // Pixel clock edge.
        uint32_t mono_bpp   : 2;  // Grayscale bytes per pixel output.
        uint32_t rgb_swap   : 1;  // Byte-swap 2BPP RGB formats after capture.
        uint32_t yuv_swap   : 1;  // Byte-swap 2BPP YUV formats after capture.
        uint32_t blc_size   : 4;  // Number of black level calibration registers.
        uint32_t raw_output : 1;  // The sensor supports raw output only.
        uint32_t yuv_format : 1;  // YUV/YVU output format.
        uint32_t jpg_format : 3;  // JPEG output format/mode.
        uint32_t cfa_format : 3;  // CFA format/pattern.
        uint32_t mipi_if    : 1;  // CSI-2 interface.
        uint32_t mipi_brate : 12; // CSI-2 interface bitrate.
        uint32_t auxiliary  : 1;  // Indicates that the sensor can be used in dual-CSI config.
        uint32_t halt_req   : 1;  // Indicates that the sensor requires sleeping before reset/shutdown.
    };

    const uint16_t *color_palette;    // Color palette used for color lookup.
    bool disable_delays;        // Set to true to disable all sensor settling time delays.
    bool disable_full_flush;    // Turn off default frame buffer flush policy when full.

    omv_csi_cb_t vsync_cb;      // VSYNC callback
    omv_csi_cb_t frame_cb;      // Frame callback

    // Sensor state
    omv_csi_sde_t sde;          // Special digital effects
    pixformat_t pixformat;      // Pixel format
    omv_csi_framesize_t framesize;  // Frame size
    int framerate;              // Frame rate
    bool first_line;            // Set to true when the first line of the frame is being read.
    bool drop_frame;            // Set to true to drop the current frame.
    uint32_t last_frame_ms;     // Last sampled frame timestamp in milliseconds.
    bool last_frame_ms_valid;   // Last sampled frame timestamp in milliseconds valid.
    omv_csi_gainceiling_t gainceiling;  // AGC gainceiling
    bool hmirror;               // Horizontal Mirror
    bool vflip;                 // Vertical Flip
    bool transpose;             // Transpose Image
    bool auto_rotation;         // Rotate Image Automatically
    bool detected;              // Set to true when the sensor is initialized.
    bool power_on;              // Set to true when the sensor is active.

    omv_i2c_t *i2c;             // SCCB/I2C bus.
    framebuffer_t *fb;          // Frame buffer pointer
    omv_clk_t *clk;             // Clock controller.
    omv_gpio_t fsync_pin;       // Frame sync pin.
    uint32_t clk_hz;            // Clock freqeuency request by this CSI.
    uint32_t reset_time_ms;     // To track elapsed time since hard-reset.
    uint32_t power_time_ms;     // To track elapsed time since power on.

    #if defined(OMV_CSI_STATS_ENABLE)
    bool stats_enabled;         // AWB stats enabled.
    omv_csi_stats_t stats;      // AWB stats struct.
    #endif // defined(OMV_CSI_STATS_ENABLE)

    #ifdef OMV_CSI_PORT_BITS
    // Additional port-specific members like device base pointer,
    // DMA handles, and additional I/Os, are included directly here.
    OMV_CSI_PORT_BITS
    #endif

    // Can be used by port or image sensor drivers to store private
    // data, internal state, or additional operations.
    void *priv;

    // Resolution table
    uint16_t resolution[OMV_CSI_FRAMESIZE_MAX][2];

    #ifdef OMV_CSI_HW_SCALE_ENABLE
    // Sensor raw resolution output (i.e. before cropping and scaling).
    uint16_t src_w;
    uint16_t src_h;
    #endif // OMV_CSI_HW_SCALE_ENABLE

    // Sensor function pointers
    int (*reset) (omv_csi_t *csi);
    int (*sleep) (omv_csi_t *csi, int enable);
    int (*shutdown) (omv_csi_t *csi, int enable);
    int (*match) (omv_csi_t *csi, size_t id);
    int (*read_reg) (omv_csi_t *csi, uint16_t reg_addr);
    int (*write_reg) (omv_csi_t *csi, uint16_t reg_addr, uint16_t reg_data);
    int (*set_pixformat) (omv_csi_t *csi, pixformat_t pixformat);
    int (*set_framesize) (omv_csi_t *csi, omv_csi_framesize_t framesize);
    int (*set_framerate) (omv_csi_t *csi, int framerate);
    int (*set_contrast) (omv_csi_t *csi, int level);
    int (*set_brightness) (omv_csi_t *csi, int level);
    int (*set_saturation) (omv_csi_t *csi, int level);
    int (*set_gainceiling) (omv_csi_t *csi, omv_csi_gainceiling_t gainceiling);
    int (*set_quality) (omv_csi_t *csi, int quality);
    int (*set_colorbar) (omv_csi_t *csi, int enable);
    int (*set_auto_gain) (omv_csi_t *csi, int enable, float gain_db, float gain_db_ceiling);
    int (*get_gain_db) (omv_csi_t *csi, float *gain_db);
    int (*set_auto_exposure) (omv_csi_t *csi, int enable, int exposure_us);
    int (*get_exposure_us) (omv_csi_t *csi, int *exposure_us);
    int (*set_auto_whitebal) (omv_csi_t *csi, int enable, float r_gain_db, float g_gain_db, float b_gain_db);
    int (*get_rgb_gain_db) (omv_csi_t *csi, float *r_gain_db, float *g_gain_db, float *b_gain_db);
    int (*set_auto_blc) (omv_csi_t *csi, int enable, int *regs);
    int (*get_blc_regs) (omv_csi_t *csi, int *regs);
    int (*set_hmirror) (omv_csi_t *csi, int enable);
    int (*set_vflip) (omv_csi_t *csi, int enable);
    int (*set_special_effect) (omv_csi_t *csi, omv_csi_sde_t sde);
    int (*set_lens_correction) (omv_csi_t *csi, int enable, int radi, int coef);
    int (*ioctl) (omv_csi_t *csi, int request, void *arg);
    int (*config) (omv_csi_t *csi, omv_csi_config_t config);
    int (*abort) (omv_csi_t *csi, bool fifo_flush, bool in_irq);
    int (*snapshot) (omv_csi_t *csi, image_t *image, uint32_t flags);
    int (*post_process) (omv_csi_t *csi, image_t *image, uint32_t flags);
    int (*isp_reset) (omv_csi_t *csi);
} omv_csi_t;

// CSI array
extern omv_csi_t csi_all[OMV_CSI_MAX_DEVICES];

// Resets the sensor state on soft-reboots.
void omv_csi_init0();

// Initializes CSI struct with default ops.
int omv_csi_init();

// Implemented by ports to set the default CSI ops.
int omv_csi_ops_init(omv_csi_t *csi);

// Return CSI instance.
// If id == -1, return the main csi, otherwise look up csi by chip-id.
omv_csi_t *omv_csi_get(int id);

// Detect and initialize the image sensor.
int omv_csi_probe(omv_i2c_t *i2c);

// Match CSI chip ID with provided ID.
int omv_csi_match(omv_csi_t *csi, size_t id);

// This function is called after a setting that may require reconfiguring
// the hardware changes, such as window size, frame size, or pixel format.
int omv_csi_config(omv_csi_t *csi, omv_csi_config_t config);

// Abort frame capture and disable IRQs, DMA etc..
int omv_csi_abort(omv_csi_t *csi, bool fifo_flush, bool in_irq);

// Call on soft-reboot
void omv_csi_abort_all(void);

// Reset the sensor to its default state.
int omv_csi_reset(omv_csi_t *csi, bool hard);

int omv_csi_get_id(omv_csi_t *csi);

// Returns the xclk freq in hz.
uint32_t omv_csi_get_clk_frequency(omv_csi_t *csi, bool nominal);

// Returns the xclk freq in hz.
int omv_csi_set_clk_frequency(omv_csi_t *csi, uint32_t frequency);

// Return true if the sensor was detected and initialized.
bool omv_csi_is_detected(omv_csi_t *csi);

// Sleep mode.
int omv_csi_sleep(omv_csi_t *csi, int enable);

// Shutdown mode.
int omv_csi_shutdown(omv_csi_t *csi, int enable);

// Read a csi register.
int omv_csi_read_reg(omv_csi_t *csi, uint16_t reg_addr);

// Write a csi register.
int omv_csi_write_reg(omv_csi_t *csi, uint16_t reg_addr, uint16_t reg_data);

// Set the sensor pixel format.
int omv_csi_set_pixformat(omv_csi_t *csi, pixformat_t pixformat);

// Set the sensor frame size.
int omv_csi_set_framesize(omv_csi_t *csi, omv_csi_framesize_t framesize);

// Set the sensor frame rate.
int omv_csi_set_framerate(omv_csi_t *csi, int framerate);

// Return the number of bytes per pixel to read from the image sensor.
uint32_t omv_csi_get_src_bpp(omv_csi_t *csi);

// Return the number of bytes per pixel to write to memory.
uint32_t omv_csi_get_dst_bpp(omv_csi_t *csi);

// Returns true if a crop is being applied to the frame buffer.
bool omv_csi_get_cropped(omv_csi_t *csi);

// Set window size.
int omv_csi_set_windowing(omv_csi_t *csi, int x, int y, int w, int h);

// Set the sensor contrast level (from -3 to +3).
int omv_csi_set_contrast(omv_csi_t *csi, int level);

// Set the sensor brightness level (from -3 to +3).
int omv_csi_set_brightness(omv_csi_t *csi, int level);

// Set the sensor saturation level (from -3 to +3).
int omv_csi_set_saturation(omv_csi_t *csi, int level);

// Set the sensor AGC gain ceiling.
// Note: This function has no effect when AGC (Automatic Gain Control) is disabled.
int omv_csi_set_gainceiling(omv_csi_t *csi, omv_csi_gainceiling_t gainceiling);

// Set the quantization scale factor, controls JPEG quality (quality 0-255).
int omv_csi_set_quality(omv_csi_t *csi, int qs);

// Enable/disable the colorbar mode.
int omv_csi_set_colorbar(omv_csi_t *csi, int enable);

// Enable auto gain or set value manually.
int omv_csi_set_auto_gain(omv_csi_t *csi, int enable, float gain_db, float gain_db_ceiling);

// Get the gain value.
int omv_csi_get_gain_db(omv_csi_t *csi, float *gain_db);

// Enable auto exposure or set value manually.
int omv_csi_set_auto_exposure(omv_csi_t *csi, int enable, int exposure_us);

// Get the exposure value.
int omv_csi_get_exposure_us(omv_csi_t *csi, int *get_exposure_us);

// Enable auto white balance or set value manually.
int omv_csi_set_auto_whitebal(omv_csi_t *csi, int enable, float r_gain_db, float g_gain_db, float b_gain_db);

// Get the rgb gain values.
int omv_csi_get_rgb_gain_db(omv_csi_t *csi, float *r_gain_db, float *g_gain_db, float *b_gain_db);

#if defined(OMV_CSI_STATS_ENABLE)
// Update RGB moving average struct.
void omv_csi_stats_update(omv_csi_t *csi, uint32_t *r, uint32_t *g, uint32_t *b, uint32_t ms);

// Get RGB moving average values.
void omv_csi_get_stats(omv_csi_t *csi, uint32_t *r, uint32_t *g, uint32_t *b);
#endif // defined(OMV_CSI_STATS_ENABLE)

// Enable auto blc (black level calibration) or set from previous calibration.
int omv_csi_set_auto_blc(omv_csi_t *csi, int enable, int *regs);

// Get black level valibration register values.
int omv_csi_get_blc_regs(omv_csi_t *csi, int *regs);

// Enable/disable the hmirror mode.
int omv_csi_set_hmirror(omv_csi_t *csi, int enable);

// Get hmirror status.
bool omv_csi_get_hmirror(omv_csi_t *csi);

// Enable/disable the vflip mode.
int omv_csi_set_vflip(omv_csi_t *csi, int enable);

// Get vflip status.
bool omv_csi_get_vflip(omv_csi_t *csi);

// Enable/disable the transpose mode.
int omv_csi_set_transpose(omv_csi_t *csi, bool enable);

// Get transpose mode state.
bool omv_csi_get_transpose(omv_csi_t *csi);

// Enable/disable the auto rotation mode.
int omv_csi_set_auto_rotation(omv_csi_t *csi, bool enable);

// Get transpose mode state.
bool omv_csi_get_auto_rotation(omv_csi_t *csi);

// Set the number of virtual frame buffers.
int omv_csi_set_framebuffers(omv_csi_t *csi, size_t count);

// Drop the next frame to match the current frame rate.
void omv_csi_throttle_framerate(omv_csi_t *csi);

// Set special digital effects (SDE).
int omv_csi_set_special_effect(omv_csi_t *csi, omv_csi_sde_t sde);

// Set lens shading correction
int omv_csi_set_lens_correction(omv_csi_t *csi, int enable, int radi, int coef);

// IOCTL function
int omv_csi_ioctl(omv_csi_t *csi, int request, void *arg);

// Set vsync callback function.
int omv_csi_set_vsync_callback(omv_csi_t *csi, omv_csi_cb_t cb);

// Set frame callback function.
int omv_csi_set_frame_callback(omv_csi_t *csi, omv_csi_cb_t cb);

// Set color palette
int omv_csi_set_color_palette(omv_csi_t *csi, const uint16_t *color_palette);

// Get color palette
const uint16_t *omv_csi_get_color_palette(omv_csi_t *csi);

// Return true if the current frame size/format fits in RAM.
int omv_csi_check_framebuffer_size(omv_csi_t *csi);

// Auto-crop frame buffer until it fits in RAM (may switch pixel format to BAYER).
int omv_csi_auto_crop_framebuffer(omv_csi_t *csi);

// Copy a single line buffer to its destination. The copying process is
// DMA-accelerated, if available, and falls back to slow software if not.
int omv_csi_copy_line(omv_csi_t *csi, void *dma, uint8_t *src, uint8_t *dst);

// Default snapshot function.
int omv_csi_snapshot(omv_csi_t *csi, image_t *image, uint32_t flags);

// Convert csi chip id to string.
const char *omv_csi_name(omv_csi_t *csi);

// Convert csi error codes to strings.
const char *omv_csi_strerror(int error);
#endif // __OMV_CSI_H__
